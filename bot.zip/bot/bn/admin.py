from django.contrib import admin
from .models import *
# Register your models here.


admin.site.register(DonnaUsers)
admin.site.register(MohammedUsers)
admin.site.register(GuestUsers)